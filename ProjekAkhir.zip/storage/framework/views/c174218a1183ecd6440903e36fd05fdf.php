<?php $__env->startSection("container"); ?>
<h1>Isi Biodata</h1>

<div class="col-sm-6">

    <form method="POST" action="/alumni/bios/<?php echo e($bio->nim); ?>" enctype="multipart/form-data">
        <?php echo method_field("put"); ?>
        <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label">Nama</label>
      <input type="name" class="form-control" id="exampleInputname1" aria-describedby="nameHelp" value="<?php echo e($bio->name); ?> " name="name">
    </div>
    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
    <div class="mb-3">
        <label for="foto" class="form-label">foto</label>
        <input type="file" class="form-control" id="foto" name="foto" placeholder="foto" value="<?php echo e(asset('storage/' . $bio->foto)); ?>">
    </div>
    <div class="mb-3">
        <label for="nim" class="form-label">NIM</label>
        <input type="text" class="form-control <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            is-invalid
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nim" name="nim" placeholder="NIM" value="<?php echo e($bio->nim); ?>">
    </div>

    <div class="mb-3">
        <label for="thnLulus" class="form-label">Tahun Lulus</label>
        <input type="text" class="form-control" id="thnLulus" name="thnLulus" placeholder="Contoh : 2015" value="<?php echo e($bio->thnLulus); ?>">
    </div>

    <div class="mb-3">
        <label for="thnLulus" class="form-label">Tempat, Tanggal Lahir</label>
        <div class="input-group">
            <input type="text" aria-label="First name" class="form-control" name="tempatLahir" placeholder="Tempat Lahir" value="<?php echo e($bio->tempatLahir); ?>">
            <input type="date" aria-label="Last name" class="form-control" name="tglLahir" value="<?php echo e($bio->tglLahir); ?>">
        </div>
    </div>

    <div class="mb-3">
        <label for="jk" class="form-label">Jenis Kelamin</label>
        <select id="jk" class="form-select" aria-label="Default select example" name="jk" >
            <option selected value="<?php echo e($bio->jk); ?>"><?php echo e($bio->jk); ?></option>
            <option value="laki-laki">Laki-laki</option>
            <option value="Perempuan">Perempuan</option>
          </select>
    </div>

    <div class="mb-3">
        <label for="agama" class="form-label">Agama</label>
        <select class="form-select" aria-label="Default select example" name="agama">
            <option selected value="<?php echo e($bio->agama); ?>"><?php echo e($bio->agama); ?></option>
            <option value="islam">Islam</option>
            <option value="kristen">Kristen</option>
            <option value="hindu">Hindu</option>
            <option value="buddha">Buddha</option>
          </select>
    </div>

    <div class="mb-3">
        <label for="kawin" class="form-label">Status Perkawinan</label>
        <select id="kawin" class="form-select" aria-label="Default select example" name="kawin">
            <option selected value="<?php echo e($bio->kawin); ?>"><?php echo e($bio->kawin); ?></option>
            <option value="belum">Belum Menikah</option>
            <option value="sudah">Sudah Menikah</option>
          </select>
    </div>

    <div class="mb-3">
        <label for="pekerjaan" class="form-label">Status Pekerjaan</label>
        <select class="form-select" aria-label="Default select example" name="pekerjaan">
            <option selected value="<?php echo e($bio->pekerjaan); ?>"> <?php echo e($bio->pekerjaan); ?></option>
            <option value="belum">Belum Bekerja</option>
            <option value="sudah">Sudah Bekerja</option>
          </select>
    </div>
    


    <button type="submit" class="btn btn-primary">Selesai</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("alumni.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zeno/ProjekAkhir/resources/views/alumni/bios/edit.blade.php ENDPATH**/ ?>