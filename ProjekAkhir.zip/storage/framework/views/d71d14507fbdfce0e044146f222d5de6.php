<?php $__env->startSection("container"); ?>

<h1 class="mt-4">Halaman biodata</h1>
<?php if(count($biodatas) < 1): ?>
    
    
    <div class="col-sm-4 bg-light p-4 rounded mt-5">
        <h5>Anda belum mengisi biodata, silahkan <a href="/alumni/bios/create">isi biodata</a></h5>
    </div>
<?php else: ?>


<div class="col-sm-4 bg-light p-4 rounded mt-5">
    <?php $__currentLoopData = $biodatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biodata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
        <label class="text-secondary" for="">Nama</label>
        <h6 class="fw-bold"><?php echo e($biodata->name); ?></h6>

        <label class="text-secondary" for="">NIM</label>
        <h6 class="fw-bold"><?php echo e($biodata->nim); ?></h6>

        <label class="text-secondary" for="">Tempat Tanggal Lahir</label>
        <h6 class="fw-bold"><?php echo e($biodata->tempatLahir); ?>, <?php echo e($biodata->tglLahir); ?></h6>

        <label class="text-secondary" for="">Jenis Kelamin</label>
        <h6 class="fw-bold"><?php echo e($biodata->jk); ?></h6>

        <label class="text-secondary" for="">Agama</label>
        <h6 class="fw-bold"><?php echo e($biodata->agama); ?></h6>

        <label class="text-secondary" for="">Status Pernikahan</label>
        <h6 class="fw-bold"><?php echo e($biodata->kawin); ?> kawin</h6>

        
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("alumni.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arie/ProjekAkhir/resources/views/alumni/bios/index.blade.php ENDPATH**/ ?>