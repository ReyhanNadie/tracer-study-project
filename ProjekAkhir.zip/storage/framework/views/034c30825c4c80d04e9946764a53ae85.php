<?php $__env->startSection("container"); ?>

<?php
use Carbon\Carbon
?>
<h1 class="mt-4">Halaman Pekerjaan</h1>
<?php if( $pekerjaan[0]->pekerjaan === 'belum'): ?>
    <div class="col-sm-4 bg-light p-4 rounded mt-5">
        <h5>Anda belum bisa mengisi data pekerjaan karena status anda belum bekerja</h5>
    </div>
<?php elseif(count($pekerjaan) < 1): ?>
    <div class="col-sm-4 bg-light p-4 rounded mt-5">
        <h5>Anda belum mengisi data pekerjaan, silahkan <a href="/alumni/works/create">isi data pekerjaan</a></h5>
    </div>
<?php else: ?>


<div class="col-sm-4 bg-light p-4 rounded mt-5">
<?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <label class="text-secondary" for="">Nama</label>
    <h6 class="fw-bold"><?php echo e($p->biodata->name); ?></h6>

    <label class="text-secondary" for="">Kategori Pekerjaan</label>
    <h6 class="fw-bold"><?php echo e($p->kategori_pekerjaan); ?></h6>

    <label class="text-secondary" for="">Bekerja Sebagai</label>
    <h6 class="fw-bold"><?php echo e($p->nama_pekerjaan); ?></h6>

    <label class="text-secondary" for="">Alamat Pekerjaan</label>
    <h6 class="fw-bold"><?php echo e($p->tempat_pekerjaan); ?></h6>

    <label class="text-secondary" for="">Mulai Bekerja</label>
    <h6 class="fw-bold"><?php echo e(Carbon::parse($p->tanggal_pekerjaan)->locale('id')->diffForHumans()); ?> (<?php echo e($p->tanggal_pekerjaan); ?>)</h6>
    <!-- <h6 class="fw-bold"><?php echo e($p->tanggal_pekerjaan); ?></h6> -->
    
    <label class="text-secondary" for="">Tahun Kelulusan</label>
    <h6 class="fw-bold"><?php echo e($p->biodata->thnLulus); ?></h6>


    <label class="text-secondary" for="">Kisaran Gaji</label>
    <h6 class="fw-bold">Rp. <?php echo e($p->gaji); ?></h6>


    <h6 class="mt-5">Edit data <a class="text-primary" href="/alumni/works/<?php echo e($p->id); ?>/edit">pekerjaan</a></h6>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("alumni.layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zeno/ProjekAkhir/resources/views/alumni/works/index.blade.php ENDPATH**/ ?>