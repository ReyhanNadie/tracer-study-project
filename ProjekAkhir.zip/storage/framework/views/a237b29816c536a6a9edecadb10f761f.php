<?php $__env->startSection("container"); ?>

    <div class="row align-items-center" style="height: 90vh">
        <div class="col-sm-3 m-auto">
            <h3 class="text-center">Silahkan Login</h3>
            <form action="" method="post">

                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                    <label for="floatingInput">Masukkan Email</label>
                </div>
                <div class="form-floating">
                    <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>
                <div>
                    <button class="btn btn-primary mt-3">Login</button>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arie/ProjekAkhir/resources/views/login.blade.php ENDPATH**/ ?>