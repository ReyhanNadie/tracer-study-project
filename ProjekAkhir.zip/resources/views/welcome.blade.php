@extends("layouts.main")

@section("container")
    <h1>test</h1>
@endsection