@extends("layouts.main")

@section("container")
    <h1>ini halaman about</h1>
@endsection